import ij.*;
import ij.gui.*;
import ij.plugin.*;
import ij.process.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.Math.*;
import java.awt.image.*;


// Align_Slice  v1.0  by G.Landini 12/Feb/2004
// With thanks to Wayne Rasband for help with the no-image test.
// 1.1 12/June/2005 added rotation and stretching, added log output based on Leon Espinosa modification
// 1.2 24/June/2005 fixed closing of window
// 1.3 19/Mar/2009 uses bicubic interpolation for resizing and rotation
// 1.4 23/Oct/2009 rotation command changed name
// 1.5 17/12/2016 added 'difference button' for easy alignment with 'next' slice. Suggested by Vincent Joseph De Andrade
// 1.6 20/12/2016 fixed 16 bit offset
// 1.7 24/09/2018 using the Diff button, assumes that one is adjusting the slice comparing to the 'Previous Slice'. 

public class Align_Slice extends Dialog
implements ActionListener, AdjustmentListener, ItemListener, WindowListener, Runnable {
	private Thread threadProcess = null;

	protected int par1 = 1;	
	protected double par2= 0.0, par3=0.0, xep, yep, rp;
	protected ImagePlus imp;
	protected ImageProcessor ip;
	protected int xe, ye, p, x, y, slices, currentSlice=1, offset;
	protected int c[] = new int [2];  //[xy]
	protected int mp[] = new int [2]; //[xy]

	protected double sp[] = new double [2]; //[xy]
	protected int r[][];
	protected int n[][];
	protected boolean dif = false, wasdif=false, colour=false;
	

	public Align_Slice () {
		super(new Frame(), "Align Slice");
		if (IJ.versionLessThan("1.42l"))
			return;

		imp = WindowManager.getCurrentImage();
		if (imp == null) {
			IJ.showMessage("Image required.");
			return;
		}

		slices= imp.getNSlices();
		ImageStatistics stats;
		stats = imp.getStatistics();
		ip = imp.getProcessor();
		int bitDepth=imp.getBitDepth();
		colour=(bitDepth==24);
		if (bitDepth==16)
			offset=((int)stats.max-(int)stats.min)/2;
		else
			offset=127;
				
		xe = ip.getWidth();
		xep=xe;
		ye = ip.getHeight();
		yep=ye;
		r = new int [xe][ye];
		n = new int [xe][ye];
		// get the default slice
		for(y=0;y<ye;y++) {
			for(x=0;x<xe;x++){
				r[x][y]=ip.getPixel(x,y);
				n[x][y]=r[x][y];// first slice has no "previous slice"
			}
		}
	
		doDialog();
	}

	public void run() {
		// You will never be here...
	}


	void align(){
		int sx=0, ex=0, sy=0, ey=0;

			for(y=0;y<ye;y++) {
				for(x=0;x<xe;x++)
					ip.putPixel(x,y, 0 );
			}
			if(c[0]>=0 && c[1]>=0) {sx=c[0]; ex= xe; sy=c[1]; ey=ye; }
			else if (c[0]<=0 && c[1]<=0){ sx=0; ex= xe+c[0]; sy=0; ey=ye+c[1]; }
			else if (c[0]<=0 && c[1]>=0){ sx=0; ex= xe+c[0]; sy=c[1]; ey=ye; }
			else if (c[0]>=0 && c[1]<=0){ sx=c[0]; ex= xe; sy=0; ey=ye+c[1]; }
			
			if(colour){ 
				for(y=sy;y<ey;y++) {
					for(x=sx;x<ex;x++)
						ip.putPixel(x, y, dif?                                                                    
						(((int)(offset+(((r[x-c[0]][y-c[1]] & 0xff0000) >> 16) - ((n[x][y] & 0xff0000) >> 16))/2) & 0xff)<<16) +
						(((int)(offset+(((r[x-c[0]][y-c[1]] & 0x00ff00) >> 8)  - ((n[x][y] & 0x00ff00) >> 8)) /2) & 0xff)<<8) +
						(((int)(offset+( (r[x-c[0]][y-c[1]] & 0x0000ff)        - ((n[x][y]) & 0x0000ff)     )  /2) & 0xff)):
						r[x-c[0]][y-c[1]]);
				}
			}
			else {
				for(y=sy;y<ey;y++) {
					for(x=sx;x<ex;x++)
						ip.putPixel(x, y, dif?offset+(r[x-c[0]][y-c[1]]-n[x][y])/2:r[x-c[0]][y-c[1]]);
				}
			}

			imp.updateAndDraw();
	}

	// Build the dialog box.
	private GridBagLayout 	layout;
	private GridBagConstraints 	constraint;
//	private Button 		bnClose;
	private Button 		bnHelp;
	private Button 		bnUp;
	private Button 		bnDn;
	private Button 		bnRt;
	private Button 		bnLt;
	private Button 		bnRvt;
	private Button 		bnRot;
	private Button 		bnWid;
	private Button 		bnHei;
	private TextField	txtpar1;
	private TextField	txtpar2;
	private TextField	txtpar3;
	private Scrollbar	scrpar1;
	private Scrollbar	scrpar2;
	private Scrollbar	scrpar3;
	private Button 		bnNextS;
	private Button 		bnPrevS;
	private Button		chkDif;
	private Checkbox	chkLog;

	private void doDialog() {
		// Layout
		layout = new GridBagLayout();
		constraint = new GridBagConstraints();
//		bnClose = new Button("   Close   ");
		bnHelp = new Button("Help");
		bnUp = new Button("Up");
		bnDn = new Button("Down");
		bnRt = new Button("Right");
		bnLt = new Button("Left");
		bnRvt = new Button("Revert");
		bnRot = new Button("Rotate");
		bnWid = new Button("Width");
		bnHei = new Button("Height");
		bnNextS = new Button("Next >");
		bnPrevS = new Button("< Prev");
		txtpar1 = new TextField(""+par1, 3);
		txtpar2 = new TextField(""+par2, 3);
		txtpar3 = new TextField(""+par3, 3);
		scrpar1	= new Scrollbar(Scrollbar.HORIZONTAL, 1, 1, 1, 101);
		scrpar2	= new Scrollbar(Scrollbar.HORIZONTAL, 0, 1, -180, 181);
		scrpar3	= new Scrollbar(Scrollbar.HORIZONTAL, 0, 1, -100, 101);
		chkDif = new Button("Diff");
		chkLog = new Checkbox("Log", null, false);

		// Panel parameters
		Panel pnMain = new Panel();
		pnMain.setLayout(layout);
		addComponent(pnMain, 0, 0, 1, 1, 2, new Label("  Distance"));
		addComponent(pnMain, 0, 1, 1, 1, 2, txtpar1);
		addComponent(pnMain, 0, 2, 1, 1, 2, scrpar1);
		addComponent(pnMain, 3, 1, 1, 1, 5, bnUp);
		addComponent(pnMain, 4, 0, 1, 1, 5, bnLt);
		addComponent(pnMain, 4, 2, 1, 1, 5, bnRt);
		addComponent(pnMain, 5, 1, 1, 1, 5, bnDn);
		addComponent(pnMain, 6, 1, 1, 1, 2, new Label("    ---"));

		addComponent(pnMain, 7, 0, 1, 1, 3, bnRot);
		addComponent(pnMain, 7, 1, 1, 1, 3, txtpar2);
		addComponent(pnMain, 7, 2, 1, 1, 3, scrpar2);
		
		addComponent(pnMain, 8, 1, 1, 1, 1, new Label("    ---"));
				
		addComponent(pnMain, 9, 0, 1, 1, 3, bnWid);
		addComponent(pnMain, 9, 1, 1, 1, 3, txtpar3);
		addComponent(pnMain, 9, 2, 1, 1, 3, scrpar3);
		addComponent(pnMain, 10, 0, 1, 1, 3, bnHei);

		addComponent(pnMain, 11, 0, 1, 1, 2, new Label("    ---"));
		addComponent(pnMain, 11, 1, 1, 1, 2, chkDif);
		addComponent(pnMain, 11, 2, 1, 1, 1, chkLog);
		addComponent(pnMain, 12, 0, 1, 1, 5, bnPrevS);
		addComponent(pnMain, 12, 1, 1, 1, 2, new Label("   Slice"));
		addComponent(pnMain, 12, 2, 1, 1, 5, bnNextS);
//		addComponent(pnMain, 14, 2, 1, 1, 5, bnClose);
		addComponent(pnMain, 14, 1, 1, 1, 5, bnHelp);

		// Add Listeners
		bnUp.addActionListener(this);
		bnDn.addActionListener(this);
		bnRt.addActionListener(this);
		bnLt.addActionListener(this);
		bnNextS.addActionListener(this);
		bnPrevS.addActionListener(this);
//		bnClose.addActionListener(this);
		bnHelp.addActionListener(this);
		scrpar1.addAdjustmentListener(this);
		scrpar1.setUnitIncrement(1);
		txtpar2.addActionListener(this);
		scrpar2.addAdjustmentListener(this);
		scrpar2.setUnitIncrement(1);
		
		txtpar3.addActionListener(this);
		scrpar3.addAdjustmentListener(this);
		scrpar3.setUnitIncrement(1);

		chkDif.addActionListener(this);

		chkLog.addItemListener(this);
		bnRvt.addActionListener(this);
		bnRot.addActionListener(this);
		bnWid.addActionListener(this);
		bnHei.addActionListener(this);
		addWindowListener(this);

		// Build panel
		add(pnMain);
		pack();
		setResizable(false);
		GUI.center(this);
		setVisible(true);
		IJ.wait(250); // work around for Sun/WinNT bug
	}

	final private void addComponent(
	final Panel pn,
	final int row, final int col,
	final int width, final int height,
	final int space,
	final Component comp) {
		constraint.gridx = col;
		constraint.gridy = row;
		constraint.gridwidth = width;
		constraint.gridheight = height;
		constraint.anchor = GridBagConstraints.NORTHWEST;
		constraint.insets = new Insets(space, space, space, space);
		constraint.weightx = IJ.isMacintosh()?90:100;
		constraint.fill = constraint.HORIZONTAL;
		layout.setConstraints(comp, constraint);
		pn.add(comp);
	}

	// Implement the listeners
    public synchronized void adjustmentValueChanged(AdjustmentEvent e) {
		if (e.getSource() == scrpar1) {
			//System.out.println("Event: " + e);
			par1=scrpar1.getValue();
			txtpar1.setText( "" + par1);
		}
		else if (e.getSource() == scrpar2){
			par2=scrpar2.getValue();
			txtpar2.setText( "" + par2);
		}
		else if (e.getSource() == scrpar3){
			par3=scrpar3.getValue();
			txtpar3.setText( "" + par3);
		}
		else if (e.getSource() == chkDif){
		}
		notify();
    }


	public synchronized  void actionPerformed(ActionEvent e) {
		//if (e.getSource() == bnClose) {
		//	dispose();
		//}
		//else if
		if (e.getSource() == bnNextS){
			if (dif) {
				dif=false;
				align();
				wasdif=true;
			}
			else 
				wasdif=false;
			
			currentSlice++;
			if (currentSlice>slices) currentSlice=slices;
			
			IJ.run("Next Slice [>]");
			imp = WindowManager.getCurrentImage();
			ip = imp.getProcessor();
			for(y=0;y<ye;y++) {
				for(x=0;x<xe;x++){
					r[x][y]=ip.getPixel(x,y);
				}
			}
			c[0]=0;
			c[1]=0;
			mp[0]=mp[1]=0;
			sp[0]=sp[1]=rp=0;
			xep=xe;
			yep=ye;
			if(chkLog.getState())
				IJ.log("-----\nNext slice: "+currentSlice);

			if(currentSlice>1){
				IJ.run("Previous Slice [<]");
				//imp = WindowManager.getCurrentImage();
				ip = imp.getProcessor();
				for(y=0;y<ye;y++) {
					for(x=0;x<xe;x++){
						n[x][y]=ip.getPixel(x,y);
					}
				}
				IJ.run("Next Slice [>]");

			}
			else{
				for(y=0;y<ye;y++) {
					for(x=0;x<xe;x++){
						r[x][y]=n[x][y];
					}
				}	
			}
			if (wasdif) {
				dif=true;
				align();
			}
		}
		else if (e.getSource() == bnPrevS){
			currentSlice--;
			if (currentSlice<1) currentSlice=1;
			
			if (dif) {
				dif=false;
				align();
				wasdif=true;
			}
			else
				wasdif=false;
				
			IJ.run("Previous Slice [<]");
			if (currentSlice>1){
				for(y=0;y<ye;y++) {
					for(x=0;x<xe;x++){
						n[x][y]=r[x][y];
					}
				}
			
				imp = WindowManager.getCurrentImage();
				ip = imp.getProcessor();
				for(y=0;y<ye;y++) {
					for(x=0;x<xe;x++){
						r[x][y]=ip.getPixel(x,y);
					}
				}
			}
			else{
				imp = WindowManager.getCurrentImage();
				ip = imp.getProcessor();
				for(y=0;y<ye;y++) {
					for(x=0;x<xe;x++){
						r[x][y]=ip.getPixel(x,y);
						n[x][y]=r[x][y];
					}
				}
			}
			
			c[0]=0;
			c[1]=0;
			mp[0]=mp[1]=0;
			sp[0]=sp[1]=rp=0;
			xep=xe;
			yep=ye;
			if(chkLog.getState())
			
				IJ.log("-----\nPrevious slice: "+currentSlice);
			if (wasdif) {
				dif=true;
				align();
			}
		}
		else if (e.getSource() == bnUp){
			c[1]-=par1; // move up
			mp[1]-=par1;
		}
		else if (e.getSource() == bnDn){
			c[1]+=par1; // move dn
			mp[1]+=par1;
		}
		else if (e.getSource() == bnRt){
			c[0]+=par1; // move right
			mp[0]+=par1;

		}
		else if (e.getSource() == bnLt){
			c[0]-=par1; // move left
			mp[0]-=par1;
		}
		else if (e.getSource() == txtpar2){
			par2= Double.parseDouble(txtpar2.getText().trim());
			//IJ.log("txtpar2 has changed");
		}
		else if (e.getSource() == bnRot){
			//rotate plane
			if (dif) {
				dif=false;
				align();
				wasdif=true;
			}
			else
				wasdif=false;
				
			rp+=par2;
			if (rp>360)
				rp-=360;
			else if (rp<-360)
				rp+=360;
			IJ.run("Rotate... ", "angle="+par2+" grid=1 interpolation=Bicubic fill slice");
			// get the 3 planes again
			imp = WindowManager.getCurrentImage();
			ip = imp.getProcessor();
			for(y=0;y<ye;y++) {
				for(x=0;x<xe;x++){
					r[x][y]=ip.getPixel(x,y);
				}
			}
			c[0]=0;
			c[1]=0;
			if (wasdif) {
				dif=true;
				align();
			}
		}
		else if (e.getSource() == txtpar3){
			par3= Double.parseDouble(txtpar3.getText().trim());
			//IJ.log("txtpar3 has changed");
			}
		else if (e.getSource() == bnWid){
			if (dif) {
				dif=false;
				align();
				wasdif=true;
			}
			else 
				wasdif=false;
			//IJ.log("Width button pressed");
			sp[0]+=par3;
			IJ.run("Scale...", "x="+((xep+par3)/xep)+" y=1 interpolation=Bicubic fill title=Untitled");
			//IJ.run("RGB Color");
			xep+=par3;
			// get the 3 planes again
			imp = WindowManager.getCurrentImage();
			ip = imp.getProcessor();
			for(y=0;y<ye;y++) {
				for(x=0;x<xe;x++){
					r[x][y]=ip.getPixel(x,y);
				}
			}
			c[0]=0;
			c[1]=0;
			if (wasdif) {
				dif=true;
				align();
			}
		}
		else if (e.getSource() == bnHei){
			if (dif) {
				dif=false;
				align();
				wasdif=true;
			}
			else 
				wasdif=false;
			
			//IJ.log("Height button pressed");
			sp[1]+=par3;
			IJ.run("Scale...", "x=1 y="+((yep+par3)/yep)+" interpolation=Bicubic fill title=Untitled");
			yep+=par3;
			// get the 3 planes again
			imp = WindowManager.getCurrentImage();
			ip = imp.getProcessor();
			for(y=0;y<ye;y++) {
				for(x=0;x<xe;x++){
					r[x][y]=ip.getPixel(x,y);
				}
			}
			c[0]=0;
			c[1]=0;
			if (wasdif) {
				dif=true;
				align();
			}
		}

		else if (e.getSource() == bnHelp) {
			IJ.showMessage("Help","Align Slice  v1.7  by G.Landini\n"+
							"Manual alignment of individual slices in a stack.\n \n"+
							"Note: Do not use the slide bar in the stack window.\n"+
							"Instead, use the panel buttons of this plugin.\n"+
							"Adjust the parameter values with the sliders.\n"+
							"'Diff' button not supported in 32bit stacks.");
		}

		else if (e.getSource() == chkDif) {
			if (!dif) dif = true; else dif = false;
		
		}
		notify();
		//IJ.showStatus("R:"+c[0]+","+c[1]);
		align();

		if(chkLog.getState()){
			IJ.log(
				(mp[0]>0?"   [right]: "+mp[0]:mp[0]<0?"   [left]: "+Math.abs(mp[0]):"")+
				(mp[1]>0?"   [down]: "+mp[1]:mp[1]<0?"   [up]: "+Math.abs(mp[1]):"")+
				(rp!=0?"   [rotate]: "+rp:"")+
				(sp[0]!=0?"   [width]: "+sp[0]:"")+
				(sp[1]!=0?"   [height]: "+sp[1]:""));
		}
		
	}

	public synchronized void itemStateChanged(ItemEvent e) {
		if(e.getSource() == chkLog)
			IJ.beep();
		notify();
	}
	public void windowActivated(WindowEvent e) {
	}

	public void windowClosing(WindowEvent e) {
		dispose();
	}

	public void windowClosed(WindowEvent e) {
	}

	public void windowDeactivated(WindowEvent e) {
	}

	public void windowDeiconified(WindowEvent e){
	}

	public void windowIconified(WindowEvent e){
	}

	public void windowOpened(WindowEvent e){
	}
}
